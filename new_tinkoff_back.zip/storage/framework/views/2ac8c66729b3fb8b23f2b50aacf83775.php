<div id="loading">
    <img id="loading-image" src="<?php echo e(asset('sources/images/bars.svg')); ?>" width="40" alt="Loading...">
</div>
<?php /**PATH E:\OSPanel\domains\new_tinkoff2\resources\views/components/loader.blade.php ENDPATH**/ ?>