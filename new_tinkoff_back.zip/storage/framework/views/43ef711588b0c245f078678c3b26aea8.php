<?php $__env->startSection('content'); ?>
    <div class="auth_container flex justify-center items-center">
        <div class="auth_card">
            <h1>Авторизация</h1>
            <form action="<?php echo e(route('auth')); ?>" method="post" class="register_form">
                <?php echo csrf_field(); ?>
                <div class="fields_wrapper flex flex-col">
                    <div>
                        <input class="!pl-2 rounded" type="text" placeholder="Логин" name="login"></div>
                    <div>
                        <input class="!pl-2 rounded password_field" type="password" placeholder="Пароль"
                               name="password">

                    </div>
                </div>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="text-danger mt-1"><?php echo e($message); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <button type="submit">Войти</button>
            </form>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OSPanel\domains\new_tinkoff2\resources\views/auth/login.blade.php ENDPATH**/ ?>