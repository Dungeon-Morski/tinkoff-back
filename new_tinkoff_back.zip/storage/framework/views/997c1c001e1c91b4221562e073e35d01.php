<div id="loading">
    <img id="loading-image" src="<?php echo e(asset('sources/images/bars.svg')); ?>" width="40" alt="Loading...">
</div>
<?php /**PATH C:\Users\nikit\PhpstormProjects\tinkoff-back\resources\views/components/loader.blade.php ENDPATH**/ ?>