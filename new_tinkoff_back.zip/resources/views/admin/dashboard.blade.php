@extends('layouts.app')

@section('content')

<h1 class="ml-5 mt-6 text-gray-900">Добро пожаловать в админ панель!</h1>

@endsection
