<div id="loading">
    <img id="loading-image" src="{{asset('sources/images/bars.svg')}}" width="40" alt="Loading...">
</div>
