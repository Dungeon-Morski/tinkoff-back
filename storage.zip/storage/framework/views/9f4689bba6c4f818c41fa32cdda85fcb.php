<?php $__env->startSection('content'); ?>

<h1 class="ml-5 mt-6 text-gray-900">Добро пожаловать в админ панель!</h1>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nikit\PhpstormProjects\tinkoff-back\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>